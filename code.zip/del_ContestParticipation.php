<?php
include 'connect.php';

$sql = "DELETE FROM `registered_events` WHERE id='".$_POST['id']."'";       

      if ($conn->query($sql) === TRUE) 
      { 
        $_SESSION['success']='Record Successfully Deleted'; } 
      else {
        $_SESSION['error']='Something Went Wrong';
      }
      ?>