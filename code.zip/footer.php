
<div id="styleSelector">
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
		
		<center><h4>© 2021 All rights reserved. Developed by IOT LAB (DEVA S - 191MC118)</h4></center>
		    
    
    <script type="text/javascript" src="theme/bower_components/jquery/js/jquery.min.js"></script>
    <script type="text/javascript" src="theme/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="theme/bower_components/popper.js/js/popper.min.js"></script>
    <script type="text/javascript" src="theme/bower_components/bootstrap/js/bootstrap.min.js"></script>
    
    <script src="theme/assets/pages/waves/js/waves.min.js"></script>
    
    <script type="text/javascript" src="theme/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>
    <script src="theme/assets/js/pcoded.min.js"></script>
    <script src="theme/assets/js/vertical/vertical-layout.min.js"></script>
    
    <script type="text/javascript" src="theme/assets/js/script.min.js"></script>

    <script src="js/lib/datatables/datatables.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="js/lib/datatables/datatables-init.js"></script>
    <script src="js/lib/sweetalert/sweetalert.min.js"></script>
    <!-- scripit init-->
    <script src="js/lib/sweetalert/sweetalert.init.js"></script>

<script src="js/ckeditor.js"></script>
<script src="js/sample.js"></script>
<script>
    initSample();
</script>
</body>



</html>
<script>
function alphaOnly(event) {
  var key = event.keyCode;
  return ((key >= 65 && key <= 90) || key == 8);
};
                                        </script>
                                        <script>
    // WRITE THE VALIDATION SCRIPT.
    function isNumber(evt) {
        var iKeyCode = (evt.which) ? evt.which : evt.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }    
</script>