<?php include('head.php');?>
<?php include('header.php');?>
<link rel="stylesheet" href="popup_style.css">
<link rel="stylesheet" href="theme/bower_components/select2/css/select2.min.css" />
<?php include('sidebar.php');
  include 'connect.php';?>
  <?php

    if(isset($_POST['btn_save']))
    {      
      extract($_POST);
      $sql = "UPDATE `registered_events` SET `rollnumber`='$rollnumber',`name`='$name',`email`='$email',`eventname`='$eventname',`organizer`='$organizer',`internshipduration`='$internshipduration',`eventdate`='$eventdate',`completeddate`='$completeddate',`certificatedetails`='$certificatedetails',`proof`='$proof', `remarks`='$remarks' WHERE id='".base64_decode($_GET['id'])."'";       

      if ($conn->query($sql) === TRUE) 
      { 
        $_SESSION['success']='Record Successfully Added'; } 
      else {
        $_SESSION['error']='Something Went Wrong';
      }
      ?>
    <script type="text/javascript">
        window.location="OnlineCourse.php";
    </script>
<?php 
    } 

?>
<?php 
  
    if(isset($_GET['id']))
    {
      $sql = "SELECT * FROM registered_events WHERE id='".base64_decode($_GET['id'])."'";                                     
      $result = $conn->query($sql);
      $i = 1;

      while($row = $result->fetch_assoc()) 
      {
        extract($row);
      }
    }
    else
    {
      $_SESSION['error']='Invalid Record';
      ?>
    <script type="text/javascript">
        window.location="Register.php";
    </script>
<?php
    }


?>
<div class="pcoded-content">
    
    <div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <i class="feather icon-watch bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Edit Online Course</h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="index.php"><i class="feather icon-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="#!">Edit Online Course</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="pcoded-inner-content">
                  
                  <div class="main-body">
                    <div class="page-wrapper">
                      
                      <div class="page-body">
                        <div class="row">
                          <div class="col-sm-12">
                            <div class="card">
                                <div class="card-block">
                                  <form class="form-horizontal" method="POST" name="userform" enctype="multipart/form-data">
                                     <div class="form-group">
                                        <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                         <div class="row">
                                            <div class="col-sm-5">
                                                <input type="hidden" name="sr_no" class="form-control" value="<?php echo $id; ?>" placeholder="Sr. No. " id="sr_no" required="">
                                            </div>
                                        </div>     
                                    </div> 
                                          <div class="form-group">
										
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Roll Number <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="rollnumber" class="form-control" value="<?php echo $rollnumber; ?>" placeholder="Roll Number " id="rollnumber">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Name <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" placeholder="Name " id="name">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Email</label>
                                                    <div class="col-sm-5">
                                                        <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" placeholder="Email " id="email">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Title Of The Course<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="eventname" class="form-control" value="<?php echo $eventname; ?>" placeholder="Course Title " id="eventname">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Organizer <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="organizer" class="form-control" value="<?php echo $organizer; ?>" placeholder="Organizer " id="organizer">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Course Duration (In Weeks)<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="internshipduration" class="form-control" value="<?php echo $internshipduration; ?>" placeholder="Course Duration " id="internshipduration" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Date Of Final Exam<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="eventdate" class="form-control" value="<?php echo $eventdate; ?>" placeholder="Date Of Final Exam" id="eventdate" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Completed Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="completeddate" class="form-control" value="<?php echo $completeddate; ?>" placeholder="Completed Date " id="completeddate" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Certificate Details (DPID)</label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="certificatedetails" class="form-control" value="<?php echo $certificatedetails; ?>" placeholder="DPID" id="certificatedetails">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Proof</label>
                                                <div class="col-sm-5">
                                               <input type="link" class="form-control" value="<?php echo $proof; ?>" placeholder="Proof Link" name="proof">
                                                </div>
                                            </div>
                                        </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Remarks</label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="remarks" class="form-control" value="<?php echo $remarks; ?>" placeholder="Remarks" id="remarks">
                                                    </div>
                                                </div>     
                                            </div>
                                        </div> 
                                    </div>
                                </div>                                        
                                <button type="submit" name="btn_save" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                                    </form>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
</div>
<?php include('footer.php');?>
<script type="text/javascript" src="theme/bower_components/select2/js/select2.full.min.js"></script>

<script type="text/javascript" src="theme/bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js">
</script>
<script type="text/javascript" src="theme/bower_components/multiselect/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="theme/assets/js/jquery.quicksearch.js"></script>

<script type="text/javascript" src="theme/assets/pages/advance-elements/select2-custom.js"></script>
<script>
  /*var option=$('#product_id').find(':selected').val();
    if(option==1)
    {
      $('#balance_div').show();
      if($('#product_price').val()!='')
      {
        $('#balance_amount').val($('#product_price').val());
      }
      else
      {
        $('#balance_amount').val(0);
      }
      
    }
    else
    {
      $('#balance_div').hide();
      $('#balance_amount').val(0);
    }*/
  $('#product_id').change(function() {
    var price=$(this).find(':selected').attr('data-price');
    $('#product_price').val(price);
  });
  
  $('#status').change(function() {
    var option=$(this).find(':selected').val();
    if(option==1)
    {
      $('#balance_div').show();
      if($('#product_price').val()!='')
      {
        $('#balance_amount').val($('#product_price').val());
      }
      else
      {
        $('#balance_amount').val(0);
      }
      
    }
    else
    {
      $('#balance_div').hide();
      $('#balance_amount').val(0);
    }
  });
</script>