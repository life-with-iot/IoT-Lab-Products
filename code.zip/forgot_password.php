<?php session_start();?>
  <?php
  include('connect.php');
if(isset($_POST['btn_forgot']))
{
$otp = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 8)), 0, 8);
 $text_email=$_POST['email'];

$sql = "SELECT * FROM admin where email ='".$text_email."' " ;
$ans = $conn->query($sql);
$res=mysqli_fetch_array($ans);
   $realemail=$res['email'];
  $person_fname=$res['fname'];  
  $person_lname=$res['lname'];
  $personname=$person_fname.$person_lname;
  $user_name = $res['username'];

  
 $msg = "Your Password is :'".$otp."'";
  $subject='Remind password';
  //$m = mail($to,$subject,$msg,$headers);
  
$otp1 = hash('sha256', $otp);
function createSalt()
{
    return '2123293dsj2hu2nikhiljdsd';
}
$salt = createSalt();
$otp_pass =  hash('sha256', $salt . $otp1);     
  
if($text_email == $realemail){
$sql = "UPDATE admin SET password ='$otp_pass' WHERE email='$text_email'";
$ans1 = $conn->query($sql);
 


$s = "select * from tbl_email_config";
$r = $conn->query($s);
$rr = mysqli_fetch_array($r);

$mail_host = $rr['mail_driver_host'];
$mail_name = $rr['name'];
$mail_username = $rr['mail_username'];
$mail_password = $rr['mail_password'];
$mail_port = $rr['mail_port'];
//$m = mail($to,$subject,$msg,$headers);
 require_once('PHPMailer/PHPMailerAutoload.php');
$mail = new PHPMailer;
$mail->isSMTP();   
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
//$mail->SMTPDebug = 2;// Set mailer to use SMTP
//Ask for HTML-friendly debug output
//$mail->Debugoutput = 'html';
$mail->Host = $mail_host;  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = $mail_username;                 // SMTP username
$mail->Password = $mail_password;                           // SMTP password
//$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail  // Enable TLS encryption, `ssl` also accepted
$mail->SMTPSecure = 'tls';
$mail->Port = $mail_port;           // or 587                         // TCP port to connect to
$mail->setFrom($mail_username, $mail_name);
//$mail->addAddress($email, $fname);     // Add a recipient
$mail->addAddress($text_email, $personname);

//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addReplyTo('info@example.com', 'Information');
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');
//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
//$mail->isHTML(true);                                  // Set email format to HTML
$mail->Subject = 'Forget Password';
$mail->Body    = "Hello, Your New Password is :'".$otp."' ";
//$mail->send();
if ($mail->send()) {
    
?>
<link rel="stylesheet" href="popup_style.css">
<div class="popup popup--icon -success js_success-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Success 
    </h1>
    <p>Send Email Successfully.....Please check Your Email</p>
    <p>
      <a href="login.php"><button class="button button--success" data-for="js_success-popup">OK</button></a>
    </p>
  </div>
</div>
<?php } else { ?>
<link rel="stylesheet" href="popup_style.css">
<div class="popup popup--icon -error js_error-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Error 
    </h1>
    <p>Something Goes Wrong.....</p>
    <p>
      <button class="button button--error" data-for="js_error-popup">Close</button>
    </p>
  </div>
</div>
<?php } ?>
    <script>
      var addButtonTrigger = function addButtonTrigger(el) {
  el.addEventListener('click', function () {
    var popupEl = document.querySelector('.' + el.dataset.for);
    popupEl.classList.toggle('popup--visible');
  });
};

Array.from(document.querySelectorAll('button[data-for]')).
forEach(addButtonTrigger);
    </script>


<?php

  

    
    }
}   

?> 
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>Trader Finance</title>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description" content="" />
      <meta name="keywords" content="bootstrap, bootstrap admin template, admin theme, admin dashboard, dashboard template, admin template, responsive" />
      <meta name="author" content="" />
      

      <link rel="icon" href="assets/assets/images/traderfinance.png" type="image/x-icon">
           
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
      
      <link rel="stylesheet" type="text/css" href="theme/bower_components/bootstrap/css/bootstrap.min.css">
      
      <link rel="stylesheet" href="theme/assets/pages/waves/css/waves.min.css" type="text/css" media="all"> <link rel="stylesheet" type="text/css" href="theme/assets/icon/feather/css/feather.css">
      
      <link rel="stylesheet" type="text/css" href="theme/assets/icon/themify-icons/themify-icons.css">
      
      <link rel="stylesheet" type="text/css" href="theme/assets/icon/icofont/css/icofont.css">
      
      <link rel="stylesheet" type="text/css" href="theme/assets/icon/font-awesome/css/font-awesome.min.css">
      
      <link rel="stylesheet" type="text/css" href="theme/assets/css/style.css"><link rel="stylesheet" type="text/css" href="theme/assets/css/pages.css">
  </head>

  <body themebg-pattern="theme1">
  
  <div class="theme-loader">
      <div class="loader-track">
          <div class="preloader-wrapper">
              <div class="spinner-layer spinner-blue">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
              <div class="spinner-layer spinner-red">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
            
              <div class="spinner-layer spinner-yellow">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
            
              <div class="spinner-layer spinner-green">
                  <div class="circle-clipper left">
                      <div class="circle"></div>
                  </div>
                  <div class="gap-patch">
                      <div class="circle"></div>
                  </div>
                  <div class="circle-clipper right">
                      <div class="circle"></div>
                  </div>
              </div>
          </div>
      </div>
  </div>
  
    <section class="login-block">
        
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    
                    <form class="md-float-material form-material" method="post">
                        <div class="text-center">
                            <img src="assets/assets/images/traderfinance.png" height="100" alt="logo.png">
                        </div>
                        <div class="auth-box card">
                            <div class="card-block">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-center txt-primary">Forgot Password</h3>
                                    </div>
                                </div>
                                <div class="form-group form-primary">
                                    <input type="email" name="email" class="form-control"  required="">
                                    <span class="form-bar"></span>
                                    <label class="float-label">Email</label>
                                </div>
                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                        <button type="submit" name="btn_forgot" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">Submit</button>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
        
    </section>
    
    
    


<script type="text/javascript" src="theme/bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="theme/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="theme/bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="theme/bower_components/bootstrap/js/bootstrap.min.js"></script>

<script src="theme/assets/pages/waves/js/waves.min.js"></script>

<script type="text/javascript" src="theme/bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>

<script type="text/javascript" src="theme/bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="theme/bower_components/modernizr/js/css-scrollbars.js"></script>
<script type="text/javascript" src="theme/assets/js/common-pages.js"></script>
</body>
</html>
