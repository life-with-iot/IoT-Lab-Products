<?php include('head.php');?>
<?php include('header.php');?>
<link rel="stylesheet" href="popup_style.css">
<link rel="stylesheet" href="theme/bower_components/select2/css/select2.min.css" />
<?php include('sidebar.php');
  include 'connect.php';?>
  <?php

    if(isset($_POST['btn_save']))
    {      
      extract($_POST);
	  $target_dir = "uploadImage/Proof/";
  $image1 = basename($_FILES["image"]["name"]);
  if($_FILES["image"]["tmp_name"]!=''){
    $image = $target_dir . basename($_FILES["image"]["name"]);
   if (move_uploaded_file($_FILES["image"]["tmp_name"], $image)) {
    
       @unlink("uploadImage/Proof/".$_POST['old_image']);
    
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
  
  }
  else {
     $image1 =$_POST['old_image'];
  }
  
      $sql = "UPDATE `registered_events` SET `email`='$email',`rollnumber`='$rollnumber',`eventname`='$eventname',`eventdate`='$eventdate',`eventweblink`='$eventweblink',`projecttitle`='$projecttitle',`eventstatus`='$eventstatus',`achivements`='$achivements',`prizedetails`='$prizedetails',`prizemoney`='$prizemoney',`certificatedetails`='$certificatedetails',`actionplancategory`='$actionplancategory',`proof`='$image1', `remarks`='$remarks' WHERE id='".base64_decode($_GET['id'])."'";       

      if ($conn->query($sql) === TRUE) 
      { 
        $_SESSION['success']='Record Successfully Added'; } 
      else {
        $_SESSION['error']='Something Went Wrong';
      }
      ?>
    <script type="text/javascript">
        window.location="Register.php";
    </script>
<?php 
    } 

?>
<?php 
  
    if(isset($_GET['id']))
    {
      $sql = "SELECT * FROM registered_events WHERE id='".base64_decode($_GET['id'])."'";                                     
      $result = $conn->query($sql);
      $i = 1;

      while($row = $result->fetch_assoc()) 
      {
        extract($row);
      }
    }
    else
    {
      $_SESSION['error']='Invalid Record';
      ?>
    <script type="text/javascript">
        window.location="Register.php";
    </script>
<?php
    }


?>
<div class="pcoded-content">
    
    <div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <i class="feather icon-watch bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Edit Customer</h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="index.php"><i class="feather icon-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="#!">Edit Customer</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="pcoded-inner-content">
                  
                  <div class="main-body">
                    <div class="page-wrapper">
                      
                      <div class="page-body">
                        <div class="row">
                          <div class="col-sm-12">
                            <div class="card">
                                <div class="card-block">
                                  <form class="form-horizontal" method="POST" name="userform" enctype="multipart/form-data">
                                     <div class="form-group">
                                        <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                         <div class="row">
                                            <div class="col-sm-5">
                                                <input type="hidden" name="sr_no" class="form-control" value="<?php echo $id; ?>" placeholder="Sr. No. " id="sr_no" required="">
                                            </div>
                                        </div>     
                                    </div> 
                                          <div class="form-group">
										
										  <div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Email <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" placeholder="Email " id="event" required>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Roll Number <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="rollnumber" class="form-control" value="<?php echo $rollnumber; ?>" placeholder="Roll Number " id="rollnumber" required>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Name Of the Event You Regisrered <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="eventname" class="form-control" value="<?php echo $eventname; ?>" placeholder="Event Name " id="eventname" required>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Organizer <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="organizer" class="form-control" value="<?php echo $organizer; ?>" placeholder="Organizer " id="organizer" required>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Event Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="eventdate" class="form-control" value="<?php echo $eventdate; ?>" placeholder="Event Date " id="eventdate" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Date Of Idea Generation<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="ideagenerationdate" class="form-control" value="<?php echo $ideagenerationdate; ?>" placeholder="Date Of Idea Generation " id="ideagenerationdate" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Review 1 Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="review1date" class="form-control" value="<?php echo $review1date; ?>" placeholder="Review 1 Date " id="review1date" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Review 2 Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="review2date" class="form-control" value="<?php echo $review2date; ?>" placeholder="Review 2 Date " id="review2date" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Review 3 Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="review3date" class="form-control" value="<?php echo $review3date; ?>" placeholder="Review 3 Date " id="review3date" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Completed Date<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="date" name="completeddate" class="form-control" value="<?php echo $completeddate; ?>" placeholder="Completed Date " id="completeddate" required="">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Event Website Link <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="eventweblink" class="form-control" value="<?php echo $eventweblink; ?>" placeholder="Event Website Link " id="eventweblink">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Title Of Your Project <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="projecttitle" class="form-control" value="<?php echo $projecttitle; ?>" placeholder="Title Of Your Project " id="projecttitle" required>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Short Explanation <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <textarea type="text" name="shortexplanation" class="form-control" placeholder="Short Explanation" id="shortexplanation" required><?php echo $shortexplanation; ?></textarea>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Team Name <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="teamname" class="form-control" value="<?php echo $teamname; ?>" placeholder="Team Name" id="teamname">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Action Plan Category <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <select class="form-control js-example-data-array" name="actionplancategory" id="actionplancategory" required>
                                                          <option value="">Select One</option>
														  <option value="Product Development" <?php if($actionplancategory== "Product Development"){ echo "selected"; } ?>>Product Development</option>
					                                      <option value="Competition" <?php if($actionplancategory== "Competition"){ echo "selected"; } ?>>Competition</option>
					                                      <option value="Project Presentation" <?php if($actionplancategory== "Project Presentation"){ echo "selected"; } ?>>Project Presentation</option>
					                                      <option value="Paper Presentation" <?php if($actionplancategory== "Paper Presentation"){ echo "selected"; } ?>>Paper Presentation</option>
					                                      <option value="Patent" <?php if($actionplancategory== "Patent"){ echo "selected"; } ?>>Patent</option>
					                                      <option value="Internship" <?php if($actionplancategory== "Internship"){ echo "selected"; } ?>>Internship</option>
					                                      <option value="Online Course" <?php if($actionplancategory== "Online Course"){ echo "selected"; } ?>>Online Course</option>
                                                        </select>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Event Status <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <select class="form-control js-example-data-array" name="eventstatus" id="eventstatus" required>
                                                          <option value="">Select One</option>
														  <option value="Not Yet Started" <?php if($eventstatus== "Not Yet Started"){ echo "selected"; } ?>>Not Yet Started</option>
					                                      <option value="On Going" <?php if($eventstatus== "On Going"){ echo "selected"; } ?>>On Going</option>
														  <option value="Completed" <?php if($eventstatus== "Completed"){ echo "selected"; } ?>>Completed</option>
                                                        </select>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Level Of Achivements <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <select class="form-control js-example-data-array" name="achivements" id="achivements" required>
                                                          <option value="">Select One</option>
														  <option value="1st Round" <?php if($achivements== "1st Round"){ echo "selected"; } ?>>1st Round</option>
					                                      <option value="2nd Round" <?php if($achivements== "2nd Round"){ echo "selected"; } ?>>2nd Round</option>
					                                      <option value="3rd Round" <?php if($achivements== "3rd Round"){ echo "selected"; } ?>>3rd Round</option>
					                                      <option value="Pre-Final Round" <?php if($achivements== "Pre-Final Round"){ echo "selected"; } ?>>Pre-Final Round</option>
					                                      <option value="Final Round Or Other" <?php if($achivements== "Final Round Or Other"){ echo "selected"; } ?>>Final Round Or Other</option>
                                                        </select>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Prize Detail <label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <select class="form-control js-example-data-array" name="prizedetails" id="prizedetails" required>
                                                          <option value="">Select One</option>
														  <option value="1st Place" <?php if($prizedetails== "1st Place"){ echo "selected"; } ?>>1st Place</option>
					                                      <option value="2nd Place" <?php if($prizedetails== "2nd Place"){ echo "selected"; } ?>>2nd Place</option>
					                                      <option value="3rd Place" <?php if($prizedetails== "3rd Place"){ echo "selected"; } ?>>3rd Place</option>
					                                      <option value="Participation Only" <?php if($prizedetails== "Participation Only"){ echo "selected"; } ?>>Participation Only</option>
                                                        </select>
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Prize Money<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="number" name="prizemoney" class="form-control" value="<?php echo $prizemoney; ?>" placeholder="Prize Money" id="prizemoney">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Certificate Details (DPID)<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="certificatedetails" class="form-control" value="<?php echo $certificatedetails; ?>" placeholder="DPID" id="certificatedetails">
                                                    </div>
                                                </div>     
                                            </div>
											<div class="form-group">
                                            <div class="row">
                                                <label class="col-sm-3 control-label">Proof</label>
                                                <div class="col-sm-9">
                                  <image class="profile-img" src="uploadImage/Proof/<?=$proof?>" style="height:70%;width:30%;">
                                  <input type="hidden" value="<?=$proof?>" name="old_image">
                                  <input type="file" class="form-control" name="image">
                                                </div>
                                            </div>
                                        </div>
											<div class="form-group">
                                                 <div class="row">
                                                    <label class="col-sm-3 control-label">Remarks<label style="color: red">*</label></label>
                                                    <div class="col-sm-5">
                                                        <input type="text" name="remarks" class="form-control" value="<?php echo $remarks; ?>" placeholder="Remarks" id="remarks">
                                                    </div>
                                                </div>     
                                            </div>
											
                                        </div> 
                                    </div>
                                </div>                                        
                                <button type="submit" name="btn_save" class="btn btn-primary btn-flat m-b-30 m-t-30">Submit</button>
                                    </form>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
</div>
<?php include('footer.php');?>
<script type="text/javascript" src="theme/bower_components/select2/js/select2.full.min.js"></script>

<script type="text/javascript" src="theme/bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js">
</script>
<script type="text/javascript" src="theme/bower_components/multiselect/js/jquery.multi-select.js"></script>
<script type="text/javascript" src="theme/assets/js/jquery.quicksearch.js"></script>

<script type="text/javascript" src="theme/assets/pages/advance-elements/select2-custom.js"></script>
<script>
  /*var option=$('#product_id').find(':selected').val();
    if(option==1)
    {
      $('#balance_div').show();
      if($('#product_price').val()!='')
      {
        $('#balance_amount').val($('#product_price').val());
      }
      else
      {
        $('#balance_amount').val(0);
      }
      
    }
    else
    {
      $('#balance_div').hide();
      $('#balance_amount').val(0);
    }*/
  $('#product_id').change(function() {
    var price=$(this).find(':selected').attr('data-price');
    $('#product_price').val(price);
  });
  
  $('#status').change(function() {
    var option=$(this).find(':selected').val();
    if(option==1)
    {
      $('#balance_div').show();
      if($('#product_price').val()!='')
      {
        $('#balance_amount').val($('#product_price').val());
      }
      else
      {
        $('#balance_amount').val(0);
      }
      
    }
    else
    {
      $('#balance_div').hide();
      $('#balance_amount').val(0);
    }
  });
</script>