<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>               
<div class="pcoded-content">
                        
                        <div class="page-header card">
                            <div class="row align-items-end">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <i class="feather icon-home bg-c-blue"></i>
                                        <div class="d-inline">
                                            <h5>Dashboard</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="page-header-breadcrumb">
                                        <ul class=" breadcrumb breadcrumb-title">
                                            <li class="breadcrumb-item">
                                                <a href="index.php"><i class="feather icon-home"></i></a>
                                            </li>
                                            <li class="breadcrumb-item"><a href="#!">Dashboard </a> </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">
                                    <div class="page-body">
                                        
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="card product-progress-card">
                                                    <div class="card-block">
                                                        <div class="row pp-main">
                                                            <a href="#" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-cube f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-blue"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' ";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Total Registered Events</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-blue" style="width:45%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="ProjectPresentation.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-tag f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-red"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Project Presentation' ";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Project Presentation</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-red" style="width:75%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="Internship.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-random f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-yellow"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Internship'";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Internship</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-yellow" style="width:65%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="Patent.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-dollar-sign f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-green"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Patent Filling' ";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Patent Filling</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-green" style="width:35%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="card product-progress-card">
                                                    <div class="card-block">
                                                        <div class="row pp-main">
                                                            <a href="OnlineCourse.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-cube f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-green"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Online Course' ";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Online Course</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-green" style="width:45%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="ProductDevelopment.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-tag f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-yellow"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Product Development'";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Product Development</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-yellow" style="width:75%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="ContestParticipation.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-random f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-red"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Contest Participation'";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Contest Participation</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-red" style="width:65%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <a href="PaperPresentation.php" class="col-xl-3 col-md-6">
                                                                <div class="pp-cont">
                                                                    <div class="row align-items-center m-b-20">
                                                                        <div class="col-auto">
                                                                            <i class="fas fa-dollar-sign f-24 text-mute"></i>
                                                                        </div>
                                                                        <div class="col text-right">
                                                                            <h2 class="m-b-0 text-c-blue"><?php 
		$unm = $_SESSION["rollnumber"];
        $sql = "SELECT count(*) as cnt FROM `registered_events` WHERE student_id ='" .$unm . "' && actionplancategory='Paper Presentation' ";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc())
        {
            echo $row['cnt'];
        } ?></h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row align-items-center m-b-15">
                                                                        <div class="col-auto">
                                                                            <p class="m-b-0">Paper Presentation</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="progress">
                                                                        <div class="progress-bar bg-c-blue" style="width:35%"></div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php include('footer.php');?> 