<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>IOT LAB</title>
    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="description" content="" />
        <meta name="keywords" content="">
        <meta name="author" content="" />
        
        <link rel="icon" href="myimages/logo.png" type="image/x-icon">
        
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Quicksand:500,700" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="theme/assets/css/font-awesome-n.min.css">
        
        <link rel="stylesheet" type="text/css" href="theme/bower_components/bootstrap/css/bootstrap.min.css">
        
        <link rel="stylesheet" href="theme/assets/pages/waves/css/waves.min.css" type="text/css" media="all">
        
        <link rel="stylesheet" type="text/css" href="theme/assets/icon/feather/css/feather.css">
        
        <link rel="stylesheet" type="text/css" href="theme/assets/css/style.css">
        <link href="theme/sweetalert/sweetalert.css" rel="stylesheet">
        <link rel="stylesheet" href="popup_style.css">
        <style>
  .select2-container
  {
    width: 100% !important;
  }
  .dt-buttons {
  display: inline-block;
  margin-bottom: 15px;
  padding-top: 5px;
}
.dt-buttons .dt-button {
  background: #1976d2 none repeat scroll 0 0;
  border-radius: 4px;
  color: #ffffff;
  margin-right: 3px;
  padding: 5px 15px;
}
.dt-buttons .dt-button:hover {
  background: #2f3d4a none repeat scroll 0 0;
}
@media (max-width: 667px) {
  .dt-buttons {
    margin-left: 10px;
  }
}
@media (max-width: 480px) {
  .dt-buttons {
    display: inline-block;
  }
}
.dataTables_wrapper .dataTables_paginate .paginate_button {
  border: 1px solid #ddd;
  box-sizing: border-box;
  color: #67757c;
  cursor: pointer;
  display: inline-block;
  min-width: 1.5em;
  padding: 0.5em 1em;
  text-align: center;
  text-decoration: none;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current,
.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
  background-color: #1976d2;
  border: 1px solid #1976d2;
  color: #ffffff !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled,
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled:active,
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
  background: transparent none repeat scroll 0 0;
  border: 1px solid #ddd;
  box-shadow: none;
  color: #67757c;
  cursor: default;
}
.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
  background-color: #1976d2;
  border: 1px solid #1976d2;
  color: white;
}
.dataTables_wrapper .dataTables_paginate .paginate_button:active {
  background-color: #67757c;
  outline: medium none;
}
.dataTables_wrapper .dataTables_paginate .ellipsis {
  padding: 0 1em;
}
.paging_simple_numbers .pagination .paginate_button {
  background: #ffffff none repeat scroll 0 0;
  padding: 0;
}
.paging_simple_numbers .pagination .paginate_button:hover {
  background: #ffffff none repeat scroll 0 0;
}
.paging_simple_numbers .pagination .paginate_button a {
  border: 0 none;
  padding: 2px 10px;
}
.paging_simple_numbers .pagination .paginate_button.active a,
.paging_simple_numbers .pagination .paginate_button:hover a {
  background: #1976d2 none repeat scroll 0 0;
  color: #ffffff;
}
.dataTables_filter,.dataTables_paginate
{
    float: right;
}
</style>
    </head>