<?php session_start();
 include('connect.php');
    if(!isset($_SESSION["rollnumber"]) || $_SESSION["role"] != "student")
    {         
?>
        <script>
            window.location="login.php";
        </script>
<?php 
 }
?>
    <body>
        
        <div class="loader-bg">
            <div class="loader-bar"></div>
        </div>
        
        <div id="pcoded" class="pcoded">
            <div class="pcoded-overlay-box"></div>
            <div class="pcoded-container navbar-wrapper">
                
                <nav class="navbar header-navbar pcoded-header">
                    <div class="navbar-wrapper">
                        <div class="navbar-logo">
                            <a href="index.php">
                                <img class="img-fluid" src="myimages/logo.png" style="width:22%;height:5%;" alt="Theme-Logo" />
                            </a>
                            <a class="mobile-menu" id="mobile-collapse" href="#!">
                                <i class="feather icon-menu icon-toggle-right"></i>
                            </a>
                            <a class="mobile-options waves-effect waves-light">
                                <i class="feather icon-more-horizontal"></i>
                            </a>
                        </div>
                        <div class="navbar-container container-fluid">
                            <ul class="nav-left">
                                <li>
                                    <a href="#!" onclick="javascript:toggleFullScreen()" class="waves-effect waves-light">
                                        <i class="full-screen feather icon-maximize"></i>
                                    </a>
                                </li>
                            </ul>
                            <ul class="nav-right">
                           <li class="user-profile header-notification">
                                <?php 
                                $sql = "select * from student_login where id = '".$_SESSION["id"]."'";
                                $query=$conn->query($sql);
                                while($row=mysqli_fetch_array($query))
                                    {
                                      //print_r($row);
                                      extract($row);
                                      $rollnumber = $row['rollnumber'];
                                      $phonenumber = $row['phonenumber'];
                                    }
                                    ?>
                                    <div class="dropdown-primary dropdown">
                                        <div class="dropdown-toggle" data-toggle="dropdown">
                                            <span><?php echo $rollnumber.' - '.$phonenumber; ?></span>
                                            <i class="feather icon-chevron-down"></i>
                                        </div>
                                        <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                                            <li>
                                                <a href="profile.php">
                                                    <i class="feather icon-user"></i> Profile

                                                </a>
                                            </li>
                                            <li>
                                                <a href="changepassword.php">
                                                    <i class="feather icon-lock"></i> Changed Password

                                                </a>
                                            </li>
                                            <li>
                                                <a href="logout.php">
                                                    <i class="feather icon-log-out"></i> Logout
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>