<?php include('head.php');?>
<?php include('header.php');?>
<?php include('sidebar.php');?>
<link rel="stylesheet" href="theme/bower_components/select2/css/select2.min.css" />
<div class="pcoded-content">
    
    <div class="page-header card">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <i class="feather icon-watch bg-c-blue"></i>
                    <div class="d-inline">
                        <h5>Contest Participation</h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="page-header-breadcrumb">
                    <ul class=" breadcrumb breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="index.php"><i class="feather icon-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="#!">Contest Participation</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="pcoded-inner-content">
                  
                  <div class="main-body">
                    <div class="page-wrapper">
                      
                      <div class="page-body">
                        <div class="row">
                          <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                   <a href="RegisterContestParticipation.php" class="btn btn-info">Register</a> 
                                </div>
                                <div class="card-block">
                                    <div class="table-responsive m-t-40">
                                    <table id="example23" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">S.NO</th>
                                                <th scope="col">Roll Number</th>
												<th scope="col">Name</th>
												<th scope="col">Email</th>
	                                            <th scope="col">National/International Event Name</th>
												<th scope="col">Organizer</th>
												<th scope="col">Idea Title</th>
												<th scope="col">Start Date Of The Event</th>
												<th scope="col">End Date Of The Event</th>
	                                            <th scope="col">Date Of Idea Generation</th>
	                                            <th scope="col">Review 1 Date</th>
                                                <th scope="col">Review 2 Date</th>
												<th scope="col">Review 3 Date</th>
                                                <th scope="col">Completed Date</th>
	                                            <th scope="col">Certificate Details (DPID)</th>
	                                            <th scope="col">Proof Link</th>
												<th scope="col">Event Status</th>
												<th scope="col">Category Of Project Competition</th>
												<th scope="col">Prize Money</th>
	                                            <th scope="col">Remarks</th>
	                                            <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php 
                                      include 'connect.php';
									  $unm = $_SESSION["rollnumber"];
									  
                                        $sql = "SELECT * FROM registered_events WHERE student_id ='" .$unm . "' && actionplancategory = 'Contest Participation'";
                                        $result = $conn->query($sql);
                                      while($row = $result->fetch_assoc()) 
                                      { ?>
                                            <tr>
                                              <td><?php echo $row['id']; ?></td>
                                              <td><?php echo $row['rollnumber']; ?></td>
											  <td><?php echo $row['name']; ?></td>
											  <td><?php echo $row['email']; ?></td>
											  <td><?php echo $row['eventname']; ?></td>
											  <td><?php echo $row['organizer']; ?></td>
											  <td><?php echo $row['ideatitle']; ?></td>
											  <td><?php echo $row['eventdate']; ?></td>
											  <td><?php echo $row['enddate']; ?></td>
											  <td><?php echo $row['ideagenerationdate']; ?></td>
											  <td><?php echo $row['review1date']; ?></td>
											  <td><?php echo $row['review2date']; ?></td>
											  <td><?php echo $row['review3date']; ?></td>
											  <td><?php echo $row['completeddate']; ?></td>
											  <td><?php echo $row['certificatedetails']; ?></td>
											  <td><a href="<?php echo $row['proof']; ?>"><?php echo $row['proof']; ?></a></td>
											  <td><?php echo $row['eventstatus']; ?></td>
											  <td><?php echo $row['categoryofcompetition']; ?></td>
											  <td><?php echo $row['prizemoney']; ?></td>
											  <td><?php echo $row['remarks']; ?></td>
                                              <td>
											  <?php
											  if($row['status']==0){
												  ?>
												  <a href="EditContestParticipation.php?id=<?=base64_encode($row['id']);?>" title="Edit"><button type="button" class="btn btn-inverse" ><i class="fa fa-edit"></i></button></a>
                                                <button class="btn btn-xs btn-danger" id="<?php echo'' .$row['id'].'';?>" onclick="showalert(this);"><i class="fa fa-trash" aria-hidden="true"></i></button>
											  <?php }else{
												  
												  echo '<p><a class="label label-success">VERIFIED</a></p>'; 
											  } ?>
											 
                                              </td>
                                            </tr>
                                          <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
</div>
<?php include('footer.php');?>
    <?php if(!empty($_SESSION['success'])) {  ?>
<div class="popup popup--icon -success js_success-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Success 
    </h1>
    <p><?php echo $_SESSION['success']; ?></p>
    <p>
      <button class="button button--success" data-for="js_success-popup">Close</button>
    </p>
  </div>
</div>
<?php unset($_SESSION["success"]);  
} ?>
<?php if(!empty($_SESSION['error'])) {  ?>
<div class="popup popup--icon -error js_error-popup popup--visible">
  <div class="popup__background"></div>
  <div class="popup__content">
    <h3 class="popup__content__title">
      Error 
    </h1>
    <p><?php echo $_SESSION['error']; ?></p>
    <p>
      <button class="button button--error" data-for="js_error-popup">Close</button>
    </p>
  </div>
</div>
<?php unset($_SESSION["error"]);  } ?>
    <script>
      var addButtonTrigger = function addButtonTrigger(el) {
  el.addEventListener('click', function () {
    var popupEl = document.querySelector('.' + el.dataset.for);
    popupEl.classList.toggle('popup--visible');
  });
};

Array.from(document.querySelectorAll('button[data-for]')).
forEach(addButtonTrigger);
    </script>
    <script type="text/javascript">
    function showalert(elem) 
  {
    var id=$(elem).attr("id");
    swal({
           title: "You Sure !!",
           text: "To Delete This Record!!",
           showCancelButton: true,
           closeOnConfirm: false,
           animation: "slide-from-top",
           inputValue:id,
           inputType:'hidden'
       },        
       function(inputValue){
         if (inputValue === false) return false;
         $.ajax({
             url: "del_ContestParticipation.php",
             data: {'id': id},
             type: "POST",
             success: function(inputValue){
              
               swal("Successfully Deleted");
               setTimeout(function(){// wait for 5 secs(2)
                  location.reload(); // then reload the page.(3)
                }, 1000); 
               }
           });
           
       });
  }

  </script>
